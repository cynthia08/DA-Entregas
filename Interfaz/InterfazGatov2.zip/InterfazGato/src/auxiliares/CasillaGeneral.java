/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package auxiliares;

/**
 *
 * @author Cyn
 */
public class CasillaGeneral {
    public ImagenCasilla ima1;
    public ImagenCasilla ima2;
    public ImagenCasilla ima3;
    public ImagenCasilla ima4;
    public ImagenCasilla ima5;
    public ImagenCasilla ima6;   
    public ImagenCasilla ima7;
    public ImagenCasilla ima8;
    public ImagenCasilla ima9;
    
}
