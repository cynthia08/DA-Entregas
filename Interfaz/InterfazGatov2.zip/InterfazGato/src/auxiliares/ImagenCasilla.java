/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package auxiliares;

import javafx.scene.image.ImageView;

/**
 *
 * @author Cyn
 */
public class ImagenCasilla {
    public ImageView imagen;
    public String id;

    public ImagenCasilla(ImageView imagen, String id) {
        this.imagen = imagen;
        this.id = id;
    }
    
    
    
}
